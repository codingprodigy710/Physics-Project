import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import StandardScaler
import numpy as np

# Load dataset for scaling
file_path = 'Data.csv'
df = pd.read_csv(file_path)

# Select input and target columns
input_feature = 'Ro'
target_columns = [col for col in df.columns if col != input_feature]

# Drop missing values
df = df.dropna()
df[target_columns] = df[target_columns].apply(pd.to_numeric, errors='coerce')
df = df.dropna()

# Prepare input and target arrays
X = df[[input_feature]].values
Y = df[target_columns].values

# Normalize the data
scaler_X = StandardScaler()
scaler_Y = StandardScaler()
X = scaler_X.fit_transform(X)
Y = scaler_Y.fit_transform(Y)

# Custom combined loss function
def custom_loss(y_true, y_pred):
    mse = tf.keras.losses.MeanSquaredError()(y_true, y_pred)
    mae = tf.keras.losses.MeanAbsoluteError()(y_true, y_pred)
    return mse + mae

# Load model with custom loss function
model = tf.keras.models.load_model('qnn_qkm_model.h5', custom_objects={'custom_loss': custom_loss})

# User input for mass density
ro_input = float(input("Enter mass density (Ro): "))

# Preprocess input
ro_input_scaled = scaler_X.transform(np.array([[ro_input]]))

# Predict
prediction_scaled = model.predict(ro_input_scaled)
prediction = scaler_Y.inverse_transform(prediction_scaled)

# Display Results
for i, col in enumerate(target_columns):
    print(f"{col}: {prediction[0, i]}")
