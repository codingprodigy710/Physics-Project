import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import StandardScaler
import numpy as np

# Load dataset
file_path = 'Data.csv'
df = pd.read_csv(file_path)

# Select input and target columns
input_feature = 'Ro'
target_columns = [col for col in df.columns if col != input_feature]

# Drop missing values
df = df.dropna()

# Convert all non-numeric data to NaN
df[target_columns] = df[target_columns].apply(pd.to_numeric, errors='coerce')

# Drop rows with NaN values after conversion
df = df.dropna()

# Prepare input and target arrays
X = df[[input_feature]].values
Y = df[target_columns].values

# Normalize the data
scaler_X = StandardScaler()
scaler_Y = StandardScaler()
X = scaler_X.fit_transform(X)
Y = scaler_Y.fit_transform(Y)

# Build the Quantum Neural Network model
model = tf.keras.Sequential([
    tf.keras.layers.Input(shape=(1,)),
    tf.keras.layers.Dense(64, kernel_initializer='he_uniform'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.LeakyReLU(alpha=0.1),
    tf.keras.layers.Dropout(0.2),
    
    tf.keras.layers.Dense(128, kernel_initializer='he_uniform'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.LeakyReLU(alpha=0.1),
    tf.keras.layers.Dropout(0.2),
    
    tf.keras.layers.Dense(256, kernel_initializer='he_uniform'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.LeakyReLU(alpha=0.1),
    tf.keras.layers.Dropout(0.2),
    
    tf.keras.layers.Dense(Y.shape[1])
])

# Custom combined loss function
def custom_loss(y_true, y_pred):
    mse = tf.keras.losses.MeanSquaredError()(y_true, y_pred)
    mae = tf.keras.losses.MeanAbsoluteError()(y_true, y_pred)
    return mse + mae

# Compile the model
model.compile(optimizer=tf.keras.optimizers.Nadam(learning_rate=0.0005), loss=custom_loss, metrics=['mae'])

# Callbacks
lr_schedule = tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=10, verbose=1)
early_stopping = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=15, restore_best_weights=True)

# Train the model
history = model.fit(X, Y, epochs=300, batch_size=32, validation_split=0.2, callbacks=[lr_schedule, early_stopping])

# Save the model
model.save('qnn_qkm_model.h5')

print("Training completed and model saved as 'qnn_qkm_model.h5'")
