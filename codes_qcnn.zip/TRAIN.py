import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
import pennylane as qml
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import joblib
import os

# Check device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("📟 Using device:", device)

# Load dataset from Kaggle file system
data_path = "/kaggle/input/qcnn-dataset/Data - Copy.csv"
df = pd.read_csv(data_path).apply(pd.to_numeric, errors="coerce").dropna()

# Prepare input and output
X = df[['Ro']].values
y = df.drop(columns=['Ro']).values

# Normalize
scaler_X = StandardScaler()
scaler_y = StandardScaler()
X_scaled = scaler_X.fit_transform(X)
y_scaled = scaler_y.fit_transform(y)

# Save scalers
joblib.dump(scaler_X, "scaler_X.pkl")
joblib.dump(scaler_y, "scaler_y.pkl")

# Split
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_scaled, test_size=0.2, random_state=42)

# Quantum setup
n_qubits = 4
dev = qml.device("default.qubit", wires=n_qubits)

@qml.qnode(dev, interface="torch", diff_method="backprop")
def quantum_conv(inputs, weights):
    for i in range(n_qubits):
        qml.RY(inputs[i], wires=i)

    for layer_weights in weights:
        for i in range(n_qubits):
            qml.RZ(layer_weights[i], wires=i)
        for i in range(n_qubits - 1):
            qml.CNOT(wires=[i, i+1])
        qml.CNOT(wires=[n_qubits - 1, 0])
    
    return [qml.expval(qml.PauliZ(i)) for i in range(n_qubits)]

class QuantumConvLayer(nn.Module):
    def __init__(self):
        super().__init__()
        self.weights = nn.Parameter(0.01 * torch.randn(3, n_qubits))  # 3 layers

    def forward(self, x):
        return torch.stack([
            torch.tensor(quantum_conv(sample, self.weights), dtype=torch.float32).to(device)
            for sample in x
        ])

class QCNN(nn.Module):
    def __init__(self, output_dim):
        super().__init__()
        self.fc1 = nn.Linear(1, n_qubits)
        self.quantum = QuantumConvLayer()
        self.fc2 = nn.Linear(n_qubits, output_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.quantum(x)
        x = self.fc2(x)
        return x

# Convert to torch tensors
X_train_torch = torch.tensor(X_train, dtype=torch.float32).to(device)
y_train_torch = torch.tensor(y_train, dtype=torch.float32).to(device)

# Model
model = QCNN(output_dim=y.shape[1]).to(device)
optimizer = optim.Adam(model.parameters(), lr=0.001)
criterion = nn.MSELoss()

# Training loop
epochs = 200
batch_size = 32

for epoch in range(epochs):
    model.train()
    epoch_loss = 0.0

    for i in range(0, len(X_train), batch_size):
        x_batch = X_train_torch[i:i+batch_size]
        y_batch = y_train_torch[i:i+batch_size]

        optimizer.zero_grad()
        predictions = model(x_batch)
        loss = criterion(predictions, y_batch)
        loss.backward()
        optimizer.step()

        epoch_loss += loss.item()

    print(f"Epoch {epoch+1}/{epochs} - Loss: {epoch_loss / len(X_train):.6f}")

# Save trained model
torch.save(model.state_dict(), "QCNN_trained_model.pth")
print("✅ Model saved as QCNN_trained_model.pth")
