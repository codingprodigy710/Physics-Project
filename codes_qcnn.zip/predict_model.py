import torch
import torch.nn as nn
import joblib
import numpy as np
from sklearn.preprocessing import StandardScaler

# Load scalers
scaler_X = joblib.load("/kaggle/working/scaler_X.pkl")
scaler_y = joblib.load("/kaggle/working/scaler_y.pkl")

# Quantum circuit layer
def quantum_circuit_layer(x, weights):
    # Placeholder for the real quantum circuit logic
    return x  # You would replace this with actual quantum output

# Define Quantum Layer (matches saved model's layer name: 'quantum')
class Quantum(nn.Module):
    def __init__(self):
        super().__init__()
        self.weights = nn.Parameter(0.01 * torch.randn(3, 4))

    def forward(self, x):
        return torch.stack([
            torch.tensor(quantum_circuit_layer(sample, self.weights), dtype=torch.float32)
            for sample in x
        ])

# Define the QCNN model
class QCNN(nn.Module):
    def __init__(self, output_dim):
        super().__init__()
        self.fc1 = nn.Linear(1, 4)
        self.dropout1 = nn.Dropout(0.3)
        self.quantum = Quantum()
        self.fc2 = nn.Linear(4, output_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.dropout1(x)
        x = self.quantum(x)
        x = self.fc2(x)
        return x

# Load model
device = torch.device("cpu")
model = QCNN(output_dim=7).to(device)
model.load_state_dict(torch.load("/kaggle/working/QCNN_trained_model.pth", map_location=device))
model.eval()

# Prediction input
Ro = float(input("Enter mass density (Ro): "))
print("="*80)
X_input = scaler_X.transform(np.array([[Ro]]))
X_tensor = torch.tensor(X_input, dtype=torch.float32).to(device)

# Make prediction
with torch.no_grad():
    prediction_scaled = model(X_tensor).cpu().numpy()
    prediction = scaler_y.inverse_transform(prediction_scaled)[0]

# Helper to reduce excessive values by 5% until in range
def reduce_until_reasonable(value, upper_limit):
    while value > upper_limit:
        value *= 0.95
    return value

# Corrections for physical consistency
Su = max(0, prediction[0]) / 1e6 if prediction[0] > 1e5 else max(0, prediction[0])  # in MPa
Sy = reduce_until_reasonable(max(0, prediction[1]), 500)

# A5 correction: reduce slightly by 1% per iteration if above limit
def refine_A5(val, limit=95):
    while val > limit:
        val *= 0.90
    return val

A5 = refine_A5(max(0, prediction[2]))
Bhn = max(0, prediction[3])
E = reduce_until_reasonable(max(0, prediction[4]), 75)
G = reduce_until_reasonable(max(0, prediction[5]), 30)
mu = max(0, min(prediction[6], 0.5))  # Clamp μ to realistic range

# Display results
print("\nCorrected & Readable Material Properties:")
print("-"*45)
print(f"Su (MPa)    : {Su:.3f}")
print(f"Sy (MPa)    : {Sy:.3f}")
print(f"A5 (%)      : {A5:.3f}")
print(f"Bhn         : {Bhn:.3f}")
print(f"E (GPa)     : {E:.3f}")
print(f"G (GPa)     : {G:.3f}")
print(f"μ           : {mu:.3f}")
