import torch
import torch.nn as nn
import joblib
import numpy as np

# Define the same model structure
class VQNN(nn.Module):
    def __init__(self):
        super(VQNN, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(1, 16),
            nn.Tanh(),
            nn.Linear(16, 32),
            nn.Tanh(),
            nn.Linear(32, 7)
        )

    def forward(self, x):
        return self.net(x)

# Load model and scalers
model = VQNN()
model.load_state_dict(torch.load("vqnn_model.pth"))
model.eval()

scaler_X = joblib.load("scaler_X.save")
scaler_y = joblib.load("scaler_y.save")

# Output property labels and their units
property_info = [
    ("Young's Modulus (E)", "MPa"),
    ("Ultimate Strength (Su)", "MPa"),
    ("Yield Strength (Sy)", "MPa"),
    ("Elongation at Break (A5)", "%"),
    ("Brinell Hardness Number (Bhn)", ""),
    ("Shear Modulus (G)", "GPa"),
    ("Poisson's Ratio (μ)", "")
]

# Menu for prediction
while True:
    choice = input("\nEnter 1 to predict, 0 to exit: ")
    if choice == '0':
        print("Exiting.")
        break
    elif choice == '1':
        try:
            ro_value = float(input("Enter mass density (Ro in kg/m^3): "))
            x_scaled = scaler_X.transform([[ro_value]])
            x_tensor = torch.tensor(x_scaled, dtype=torch.float32)
            with torch.no_grad():
                y_pred_scaled = model(x_tensor).numpy()
            y_pred = scaler_y.inverse_transform(y_pred_scaled)

            print("\nPredicted Material Properties:")
            for (label, unit), value in zip(property_info, y_pred[0]):
                print(f"- {label}: {value:.3f} {unit}")
        except Exception as e:
            print("Error:", e)
    else:
        print("Invalid input. Try again.")
